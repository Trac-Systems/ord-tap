document.getElementsByTagName('video')[0].addEventListener('click', (event) => {
  event.target.controls = true;
});
